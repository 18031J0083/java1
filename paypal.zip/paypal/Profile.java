package in.msitprogram.jntu.paypal.accounts;

import java.io.Serializable;

public class Profile implements Serializable{
	
	private String name;
	private String address;
	private String phone;
	public Profile(String name, String address,String phone)
	{
		this.name=name;
		this.address=address;
		this.phone=phone;
	}
	public String getName()
	{
		return name;
	}
	public String getaddress()
	{
		return address;
	}
	public String getPhone()
	{
		return phone;
	}
	public String toString()
	{
		return "Name:"+name+"\n"+"Address:"+address+"\n"+"Phone"+phone;
	}
}
