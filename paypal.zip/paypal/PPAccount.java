package in.msitprogram.jntu.paypal.accounts;

import java.io.Serializable; 
import java.util.ArrayList;

public class PPAccount implements Serializable
{
	/**
	 * 
	 */
	public Profile profile;
	private String email;
	private float accountBal;
	private boolean isActivated;
	private String activationCode;
	private ArrayList<Transaction> transactions=new ArrayList<Transaction>();
	
	public PPAccount(Profile profile,String email) {
		this.profile=profile;
		this.email=email;
		// TODO Auto-generated constructor stub
	}

	public Profile getProfile() {
		return profile;
	}

	public void setProfile(Profile profile) {
		this.profile = profile;
	}

	public float getAccountBal() {
		return accountBal;
	}

	public void setAccountBal(float accountBal) {
		this.accountBal = accountBal;
	}

	public boolean isActivated() {
		return isActivated;
	}

	public void setActivated(boolean isActivated) {
		this.isActivated = isActivated;
	}

	public String getActivationCode() {
		return activationCode;
	}

	public void setActivationCode(String activationCode) {
		this.activationCode = activationCode;
	}

	public ArrayList<Transaction> getTransactions() {
		//System.out.println("ghj");
		return transactions;
	}

	public void setTransactions(Transaction transaction) {
		//System.out.println("ghj");
		this.transactions.add(transaction);
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String toString()
	{
		// implement this function to return a beautiful looking string
		// to display the summary of the account
		return "Email:"+email+"\n"+/*"Balance:"+this.accountBal*/"\n"+profile;
	}

	public void activate(String activationCode) 
	{
		
		// TODO Auto-generated method stub
		
	}
	
	public void suspend() 
	{
		// TODO Auto-generated method stub
	}


	public boolean withdraw(float withdrawAmount) {
		this.accountBal=this.accountBal-withdrawAmount;
		return false;
	}


	public boolean addFunds(float creditAmount) 
	{
		this.accountBal=this.accountBal+creditAmount;
		return false;
	}
	
	public boolean sendMoney(float creditAmount) 
	{
		
		return false;
	}
	
	public boolean requestMoney(float creditAmount) 
	{
		
		return false;
	}

	public String getEmail() {
		// TODO Auto-generated method stub
		return email;
	}
	
}
