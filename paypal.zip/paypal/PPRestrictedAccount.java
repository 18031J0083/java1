package in.msitprogram.jntu.paypal.accounts;

public class PPRestrictedAccount extends PPAccount {
	private String parentEmail;
	private float withdrawLimit;
	public String getParentEmail() {
		return parentEmail;
	}


	public void setParentEmail(String parentEmail) {
		this.parentEmail = parentEmail;
	}


	public float getWithdrawLimit() {
		return withdrawLimit;
	}


	public void setWithdrawLimit(float withdrawLimit) {
		this.withdrawLimit = withdrawLimit;
	}


	


	public PPRestrictedAccount(Profile profile,String email)
	{
		super(profile,email);
		// TODO Auto-generated constructor stub
	}

}
