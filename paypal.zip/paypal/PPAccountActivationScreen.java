package in.msitprogram.jntu.paypal.console;

import in.msitprogram.jntu.paypal.accounts.PPAccount;
import in.msitprogram.jntu.paypal.persistance.DataStore;
import in.msitprogram.jntu.paypal.utils.PPToolkit;

import java.io.IOException;
import java.util.Scanner;

public class PPAccountActivationScreen {
	
	public static void show() throws Exception {
		PPAccount account = null;
		String email = ""; //change to get console input
		System.out.println(" 1. Suspanding \n 2. ACTIVATING");
		Scanner sc = new Scanner(System.in);
		int N=sc.nextInt();
		switch(N)
		{
		case 1: System.out.println("Enter Email");
		         email=sc.next();
		         try{
			   account = DataStore.lookupAccount(email);
		         }
		         catch(Exception e)
		         {
		        	 
		         }
		         finally
		         {
			        if(account!=null)
			          {
				        if(account.isActivated())
				        {
				        	account.setActivated(false);
				        	DataStore.writeAccount(account);
				        	System.out.println("your account is suspended");
				        	MainMenu.show();
				        }
			         }
			        else
			        {
			        	System.out.println("Your account doesnt exists ");
			        	MainMenu.show();
			        }
		         }
		         System.out.println("Your account is not activated yet");
		         MainMenu.show();
		         break;
		case 2:System.out.println("Enter Email");
        email=sc.next();
        try{
	   account = DataStore.lookupAccount(email);
        }
        catch(Exception e)
        {
       	 
        }
        finally
        {
	        if(account!=null)
	          {
		        if(!account.isActivated())
		        {
		        	String s=account.getActivationCode();
		        	int i;
		        	for(i=0;i<3;i++)
		        	{
		        		System.out.println("Enter your activation code");
			        	String em=sc.next();
		        		System.out.println("You have"+(3-i)+"Attempts");
		        	if(em.equals(s))
		        	{
		        		account.setActivated(true);
		        		System.out.println("Your account is activated");
		        		DataStore.writeAccount(account);
		        		MainMenu.show();
		        	}
		        	}
		        	System.out.println("No of Attempts Exceeded");
		        }
	         }
	        else
	        {
	        	System.out.println("Your account doesnt exists ");
	        }
        } 
		}
		/*
		 * TODO
		 * fetch the account object using email address
		 * check if the account is suspended
		 * if suspended then activate it
		 * if activation code invalid, retry for 2 more attempts
		 * on successful activation show main menu
		 * on failure show the error message and continue to main menu
		 */				
		
		
		
		//check if account is active. if yes then ask for suspending it
		
		// if yes suspend it if not go back to main menu
		
		// accept activation code, check if valid, if not give 2 more attempts
		
		//proceed to main menu
		
	
	}

}